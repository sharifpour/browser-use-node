export * from './config';
export * from './types';

// Re-export specific types for convenience
export type { BrowserState, DOMElementTree, TabInfo } from './types';
